def penjumlahan(a,b):
    hasil=a+b
    print("Hasil Penjumlahan Adalah =", hasil)

def pengurangan(a,b):
    hasil=a-b
    print("Hasil Pengurangan Adalah =", hasil)

def pembagian(a,b):
    hasil=a/b
    print("Hasil Pembagian Adalah =", hasil)

def pekalian(a,b):
    hasil=a*b
    print("Hasil Perkalian Adalah =", hasil)

def TandaKurung(a,b,c):
    hasil=a+(b+c)
    print("Hasil Tanda Kurung Adalah =", hasil)

def perpangkatan(a,b):
    hasil=a**b
    print("Hasil Perpangkatan Adalah =", hasil)

def modulus(a,b):
    hasil=a%b
    print("Hasil Modulus Adalah =", hasil)

def increment(a,b):
    hasil=a++b
    print("Hasil Increment Adalah =", hasil)

def decrement(a,b):
    hasil=a--b
    print("Hasil Decrement Adalah =", hasil)

def OperasiHitungCampuran(a,b,c):
    hasil=a+b-c
    print("Hasil Operasi Hitung Campuran Adalah =", hasil)
