def LuasPersegi(s1,s2):
    hasil=s1*s2
    print("Hasilnya Luas Persegi Adalah =", hasil)

def KelilingPersegi(s):
   hasil=4*s
   print("Hasilnya Keliling Persegi Adalah =", hasil)

def LuasPersegiPanjang(p,l):
   hasil=p*l
   print("Hasilnya Luas Persegi Panjang Adalah =", hasil)

def KelilingPersegiPanjang(p,l):
   hasil=2*(p+l)
   print("Hasilnya Keliling Persegi Panjang Adalah =", hasil)

def LuasSegitiga(a,t):
   hasil=a*t/2
   print("Hasilnya Luas Segitiga Adalah =", hasil)

def KelilingSegitiga(a,b,c):
   hasil=a+b+c
   print("Hasilnya Keliling Segitiga Adalah =", hasil)

def LuasJajarGenjang(a,t):
   hasil=a*t
   print("Hasilnya Luas Jajar Genjang Adalah =", hasil)

def KelilingJajarGenjang(a,b):
   hasil=2*(a+b)
   print("Hasilnya Keliling Jajar Genjang Adalah =", hasil)

def LuasBelahKetupat(d1,d2):
   hasil=d1*d2/2
   print("Hasilnya Luas Belah Ketupat Adalah =", hasil)

def KelilingBelahKetupat(s):
   hasil=s*4
   print("Hasilnya Keliling Belah Ketupat Adalah =", hasil)

def LuasLayangLayang(d1,d2):
   hasil=d1*d2/2
   print("Hasilnya Luas Layang Layang Adalah =", hasil)

def KelilingLayangLayang(a,c):
   hasil=2*(a+c)
   print("Hasilnya Keliling Layang Layang Adalah =", hasil)

def LuasLingkaran(r):
   hasil=3,14*r
   print("Hasilnya Luas Lingkaran Adalah =", hasil)

def KelilingLingkaran(r):
   hasil=2*3,14*r
   print("Hasilnya Keliling Lingkaran Adalah =", hasil)